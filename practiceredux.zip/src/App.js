import logo from './logo.svg';
import './App.css';
import CustomerAdd from './CustomerAdd';
import { Provider } from 'react-redux';
import { ReduxStore } from './Store';
import CustomerList from './CustomerList';
import Login from './Login';

function App() {
  return (
    <Provider store={ReduxStore}>
      <div className="App">
        {/* <CustomerAdd />
        <CustomerList /> */}
        <Login />
      </div>

    </Provider>

  );
}

export default App;
