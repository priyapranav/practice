import { configureStore, createSlice } from "@reduxjs/toolkit";
const customerList = [];
const CustomerSlice = createSlice({
    name: "cutomer",
    initialState: customerList,
    reducers: {
        addCustomer(state, action) {
            state.push(action.payload)

        },
        delCustomer(state, action) {
            const index = action.payload
            return state.filter((val, i) => i !== index)

        }
    }

})
export const { addCustomer } = CustomerSlice.actions;
export const { delCustomer } = CustomerSlice.actions;

export const ReduxStore = configureStore({
    devTools: "true",
    reducer: {
        customer: CustomerSlice.reducer
    }
})



