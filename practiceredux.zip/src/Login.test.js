import { render, screen } from "@testing-library/react"
import Login from "./Login"

test("check login render", () => {
    render(<Login />)
    expect(screen.findByPlaceholderText('UserName')).toBeInTheDocument

})