import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { delCustomer } from "./Store";

export default function CustomerList() {
    const dispatch = useDispatch();
    const customersList = useSelector((storeData) => storeData.customer)
    const deleteCutomer = (index) => {
        dispatch(delCustomer(index))

    }


    return (
        <>
            {customersList.map((val, index) => <li key={index}>{val} <button onClick={() => deleteCutomer(index)}>delete</button></li>)}
        </>

    )

}