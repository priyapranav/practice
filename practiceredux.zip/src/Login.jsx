import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import React, { useState } from "react";

export default function Login() {
    const [user, setUser] = useState("")
    const [password, setPassword] = useState("")
    const [count, setCount] = useState(0)

    const login = () => {

    }
    const increment = () => {
        // setCount(count + 1)
        // setCount(count + 1)
        setCount(prev => prev + 1)
        setCount(prev => prev + 1)
    }
    const decrement = () => {
        setCount(count - 1)
        setCount(count - 1)
    }


    const [value, setValue] = useState('');
    return (
        <div>
            <input placeholder="UserName" type="text" value={user}
                onChange={(e) => { setUser(e.target.value) }}>
            </input>

            <input placeholder="Password" type="password" value={password}
                onChange={(e) => { setPassword(e.target.value) }}>
            </input>
            <button onClick={login}>Login</button><br></br>

            <button style={{ marginTop: "30px" }} onClick={increment}>+</button>
            <text>{count}</text>
            <button onClick={decrement}>-</button>
            <div>
                <ReactQuill theme="snow" value={value} onChange={(e) => {
                    console.log("target", e)
                    setValue(e)
                }} />
            </div>
        </div>
    )
}