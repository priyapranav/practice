import React, { useState } from "react"
import { addCustomer } from "./Store"
import { useDispatch } from "react-redux"

export default function CustomerAdd() {
    const [input, setInput] = useState("")
    const dispatch = useDispatch()

    const addCustomerList = () => {

        dispatch(addCustomer(input))
        setInput("")

    }
    return (
        <>
            <h3>Add Customer</h3>
            <input type="text" value={input} onChange={(e) => { setInput(e.target.value) }} />
            <button onClick={addCustomerList}>Add</button>
        </>

    )



}
